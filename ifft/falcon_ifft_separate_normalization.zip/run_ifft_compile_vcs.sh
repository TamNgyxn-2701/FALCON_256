#!/bin/sh
set -eu

# Save this script under rtl/transform/tb/falcon_twiddle_index_verify/.
TB_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ROOT=$(CDPATH= cd -- "$TB_DIR/../../../.." && pwd)
DW=/home/eda/synopsys/syn_vD-2010.03-SP4/dw/sim_ver
cd "$TB_DIR"

vcs -sverilog -timescale=1ns/1ps \
  "+incdir+$DW" \
  "$DW/DW_fp_addsub.v" "$DW/DW_fp_add.v" "$DW/DW_fp_mult.v" \
  "$ROOT/rtl/arith/fp64/fp64_add.v" \
  "$ROOT/rtl/arith/fp64/fp64_mul.v" \
  "$ROOT/rtl/arith/fp64/fp64_neg.v" \
  "$ROOT/rtl/transform/fft/fft_complex_mul.v" \
  "$ROOT/rtl/transform/fft/fft_butterfly.v" \
  "$ROOT/rtl/transform/fft/DELAY_BUFFER.v" \
  "$ROOT/rtl/transform/ifft/ifft_normalize_fp64.v" \
  "$ROOT/rtl/transform/fft/ifft_stage_fp64.v" \
  "$ROOT/rtl/transform/fft/IFFT.v" \
  -top IFFT -o simv_ifft_compile \
  2>&1 | tee ifft_compile.log

echo "Compile succeeded; IFFT functionality is not verified yet."
