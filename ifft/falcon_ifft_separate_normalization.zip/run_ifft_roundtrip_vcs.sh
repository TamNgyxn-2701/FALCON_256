#!/bin/sh
set -eu

# Keep this script and TB in rtl/transform/tb/falcon_twiddle_index_verify.
TB_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ROOT=$(CDPATH= cd -- "$TB_DIR/../../../.." && pwd)
DW=/home/eda/synopsys/syn_vD-2010.03-SP4/dw/sim_ver
FFT_GOLDEN="$ROOT/golden/memh/case_000/fft/b00_fft.memh"
PRE_GOLDEN="$ROOT/golden/memh/case_000/basis/b00_prefft.memh"

for f in "$FFT_GOLDEN" "$PRE_GOLDEN" "$TB_DIR/falcon_gm_re.memh" "$TB_DIR/falcon_gm_im.memh";do
    if [ ! -r "$f" ];then
        echo "FAIL missing: $f" >&2
        exit 1
    fi
done

cd "$TB_DIR"
vcs -sverilog -timescale=1ns/1ps \
  "+incdir+$DW" \
  "$DW/DW_fp_addsub.v" "$DW/DW_fp_add.v" "$DW/DW_fp_mult.v" \
  "$ROOT/rtl/arith/fp64/fp64_add.v" \
  "$ROOT/rtl/arith/fp64/fp64_mul.v" \
  "$ROOT/rtl/arith/fp64/fp64_neg.v" \
  "$ROOT/rtl/transform/fft/fft_complex_mul.v" \
  "$ROOT/rtl/transform/fft/fft_butterfly.v" \
  "$ROOT/rtl/transform/fft/DELAY_BUFFER.v" \
  "$ROOT/rtl/transform/ifft/ifft_normalize_fp64.v" \
  "$ROOT/rtl/transform/ifft/ifft_stage_fp64.v" \
  "$ROOT/rtl/transform/ifft/IFFT.v" \
  falcon_gm_rom.v tb_ifft_roundtrip_golden.v \
  -top tb_ifft_roundtrip_golden -o simv_ifft_roundtrip

./simv_ifft_roundtrip \
  "+FFT_MEMH=$FFT_GOLDEN" "+PRE_MEMH=$PRE_GOLDEN" \
  | tee ifft_roundtrip.log

grep -q '^PASS: IFFT numerical roundtrip WITH RTL FP64 normalization$' ifft_roundtrip.log
